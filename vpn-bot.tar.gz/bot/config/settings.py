"""
Configuration module for VPN Telegram Bot
"""

import os
from pathlib import Path
from dotenv import load_dotenv

# Корень проекта (папка, где run.py). Загружаем .env оттуда с override=True,
# чтобы значение из файла (Vercel) всегда перебивало переменную окружения (ngrok)
_PROJECT_ROOT = Path(__file__).resolve().parent.parent.parent
load_dotenv(_PROJECT_ROOT / ".env", override=True)


class Config:
    """Bot configuration settings"""
    
    # Telegram Bot Settings
    BOT_TOKEN = os.getenv('BOT_TOKEN')
    ADMIN_IDS = [int(id.strip()) for id in os.getenv('ADMIN_IDS', '').split(',') if id.strip()]
    
    # Database Settings (путь к sqlite делаем абсолютным, чтобы один и тот же файл использовался при любом cwd)
    _db_url = os.getenv('DATABASE_URL', 'sqlite:///vpn_bot.db')
    if _db_url.startswith('sqlite:///') and not _db_url.startswith('sqlite:////'):
        _db_path = _PROJECT_ROOT / _db_url.replace('sqlite:///', '').lstrip('/')
        DATABASE_URL = 'sqlite:///' + str(_db_path).replace('\\', '/')
    else:
        DATABASE_URL = _db_url
    
    # Payment Settings
    YOOMONEY_TOKEN = os.getenv('YOOMONEY_TOKEN')
    QIWI_TOKEN = os.getenv('QIWI_TOKEN')
    CRYPTOMUS_API_KEY = os.getenv('CRYPTOMUS_API_KEY')
    CRYPTOMUS_MERCHANT_ID = os.getenv('CRYPTOMUS_MERCHANT_ID')
    
    # VPN Settings
    VPN_SERVER_URL = os.getenv('VPN_SERVER_URL')
    VPN_API_KEY = os.getenv('VPN_API_KEY')
    
    # Bot Settings
    DEFAULT_LANGUAGE = os.getenv('DEFAULT_LANGUAGE', 'ru')
    DEBUG = os.getenv('DEBUG', 'False').lower() == 'true'
    LOG_LEVEL = os.getenv('LOG_LEVEL', 'INFO')
    
    # Subscription Plans (in rubles)
    PLAN_1_MONTH_PRICE = int(os.getenv('PLAN_1_MONTH_PRICE', 299))
    PLAN_3_MONTH_PRICE = int(os.getenv('PLAN_3_MONTH_PRICE', 799))
    PLAN_6_MONTH_PRICE = int(os.getenv('PLAN_6_MONTH_PRICE', 1499))
    PLAN_12_MONTH_PRICE = int(os.getenv('PLAN_12_MONTH_PRICE', 2699))
    
    # Referral System
    REFERRAL_BONUS_PERCENT = int(os.getenv('REFERRAL_BONUS_PERCENT', 10))
    REFERRAL_MIN_PAYOUT = int(os.getenv('REFERRAL_MIN_PAYOUT', 100))
    
    # Support Configuration
    SUPPORT_USERNAME = os.getenv('SUPPORT_USERNAME', 'vpn_support')
    SUPPORT_CHAT_ID = os.getenv('SUPPORT_CHAT_ID')
    
    # Mini App (Web App) — HTTPS URL. Если задан, в меню показывается кнопка «Открыть приложение»
    WEBAPP_URL = (os.getenv('WEBAPP_URL') or '').strip() or None
    # API для личного кабинета в Mini App (проверка подписки). Если задан, в URL мини-апп добавляется ?api=...
    MINIAPP_API_URL = (os.getenv('MINIAPP_API_URL') or '').strip() or None
    # Username бота без @ — передаётся в мини-апп для кнопки «Оплатить» (открытие бота с start=pay_1month и т.д.)
    BOT_USERNAME = (os.getenv('BOT_USERNAME') or '').strip() or None
    
    @classmethod
    def validate(cls):
        """Validate required configuration"""
        if not cls.BOT_TOKEN:
            raise ValueError("BOT_TOKEN is required")
        if not cls.ADMIN_IDS:
            raise ValueError("At least one ADMIN_ID is required")
        return True


# Subscription plans configuration
SUBSCRIPTION_PLANS = {
    '1_month': {
        'name': '1 месяц',
        'price': Config.PLAN_1_MONTH_PRICE,
        'duration_days': 30,
        'description': '🚀 Базовый план на 1 месяц',
        'emoji': '🥉',
        'popular': False
    },
    '3_months': {
        'name': '3 месяца',
        'price': Config.PLAN_3_MONTH_PRICE,
        'duration_days': 90,
        'description': '🔥 Популярный план на 3 месяца',
        'emoji': '🥈',
        'popular': True
    },
    '6_months': {
        'name': '6 месяцев',
        'price': Config.PLAN_6_MONTH_PRICE,
        'duration_days': 180,
        'description': '💎 Выгодный план на полгода',
        'emoji': '🥇',
        'popular': False
    },
    '12_months': {
        'name': '1 год',
        'price': Config.PLAN_12_MONTH_PRICE,
        'duration_days': 365,
        'description': '👑 Максимальная выгода на целый год',
        'emoji': '💰',
        'popular': False
    }
}

# Payment methods configuration
PAYMENT_METHODS = {
    'yoomoney': {
        'name': 'ЮMoney',
        'emoji': '💳',
        'description': 'Банковские карты, электронные кошельки'
    },
    'qiwi': {
        'name': 'QIWI',
        'emoji': '🥝',
        'description': 'QIWI кошелек, банковские карты'
    },
    'crypto': {
        'name': 'Криптовалюты',
        'emoji': '₿',
        'description': 'Bitcoin, Ethereum, USDT и другие'
    }
}