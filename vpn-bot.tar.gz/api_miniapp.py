# -*- coding: utf-8 -*-
"""
API для Mini App Bit VPN: проверка initData и выдача данных пользователя и подписки.
Запуск (из корня проекта): uvicorn api_miniapp:app --host 0.0.0.0 --port 8765
Или: python -m uvicorn api_miniapp:app --host 0.0.0.0 --port 8765
"""

import os
import sys
import json
import hmac
import hashlib
import logging
from urllib.parse import unquote
from datetime import datetime

# Корень проекта
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from dotenv import load_dotenv
load_dotenv()

from fastapi import FastAPI, HTTPException, Header, Request
from fastapi.middleware.cors import CORSMiddleware

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

app = FastAPI(title="Bit VPN Mini App API", version="1.0")
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

BOT_TOKEN = os.getenv("BOT_TOKEN")
if not BOT_TOKEN:
    logger.warning("BOT_TOKEN not set — initData validation will fail")


def validate_init_data(init_data: str) -> dict | None:
    """Validate Telegram Web App initData, return parsed dict or None."""
    if not init_data or not BOT_TOKEN:
        return None
    try:
        parsed = {}
        hash_val = ""
        for chunk in init_data.split("&"):
            if "=" not in chunk:
                continue
            key, _, value = chunk.partition("=")
            value = unquote(value)
            if key == "hash":
                hash_val = value
                continue
            parsed[key] = value
        if not hash_val:
            return None
        data_check = "\n".join(f"{k}={parsed[k]}" for k in sorted(parsed.keys()))
        secret = hmac.new(
            b"WebAppData",
            BOT_TOKEN.encode(),
            hashlib.sha256
        ).digest()
        expected = hmac.new(secret, data_check.encode(), hashlib.sha256).hexdigest()
        if expected != hash_val:
            return None
        return parsed
    except Exception as e:
        logger.debug("validate_init_data: %s", e)
        return None


def get_telegram_user_from_init(parsed: dict) -> tuple[int | None, dict | None]:
    """Extract telegram user id and dict from validated init_data (user is JSON string). Returns (telegram_id, user_dict)."""
    user_str = parsed.get("user")
    if not user_str:
        return None, None
    try:
        user = json.loads(user_str)
        return int(user.get("id")), user
    except (json.JSONDecodeError, TypeError, ValueError):
        return None, None


# Импорт БД после добавления пути
from bot.config.settings import Config, SUBSCRIPTION_PLANS
from bot.models.database import DatabaseManager
from bot.utils.helpers import format_date, get_server_flag

db_manager = DatabaseManager(Config.DATABASE_URL)


def plan_type_to_name(plan_type: str) -> str:
    """Human-readable plan name."""
    return SUBSCRIPTION_PLANS.get(plan_type, {}).get("name", plan_type.replace("_", " "))


@app.get("/")
def root():
    return {"service": "Bit VPN Mini App API", "status": "ok"}


@app.post("/api/miniapp/me")
async def miniapp_me(request: Request):
    """
    Accept Telegram initData (JSON body: {"initData": "..."} or header X-Telegram-Init-Data),
    validate and return user + subscription for Mini App.
    """
    body = {}
    try:
        body = await request.json()
    except Exception:
        pass
    init_data = (body.get("initData") or request.headers.get("X-Telegram-Init-Data") or "").strip()
    if not init_data:
        raise HTTPException(status_code=400, detail="initData required")

    parsed = validate_init_data(init_data)
    if not parsed:
        raise HTTPException(status_code=401, detail="Invalid initData")

    telegram_id, init_user = get_telegram_user_from_init(parsed)
    if not telegram_id:
        raise HTTPException(status_code=400, detail="user not in initData")

    def user_row(u):
        return {
            "telegram_id": u.telegram_id,
            "first_name": u.first_name,
            "last_name": u.last_name,
            "username": u.username,
        }

    def init_user_row():
        return {
            "telegram_id": telegram_id,
            "first_name": (init_user or {}).get("first_name"),
            "last_name": (init_user or {}).get("last_name"),
            "username": (init_user or {}).get("username"),
        }

    session = db_manager.get_session()
    try:
        from bot.models.database import User
        user = session.query(User).filter_by(telegram_id=telegram_id).first()
        if not user:
            return {
                "ok": True,
                "user": init_user_row(),
                "subscription": None,
            }

        _ = list(user.subscriptions)  # load relationship
        sub = user.active_subscription
        if not sub:
            return {
                "ok": True,
                "user": user_row(user),
                "subscription": None,
            }

        return {
            "ok": True,
            "user": user_row(user),
            "subscription": {
                "plan_type": sub.plan_type,
                "plan_name": plan_type_to_name(sub.plan_type),
                "end_date": sub.end_date.isoformat() if sub.end_date else None,
                "end_date_formatted": format_date(sub.end_date) if sub.end_date else None,
                "days_remaining": sub.days_remaining,
                "server_location": sub.server_location or "",
                "server_flag": get_server_flag(sub.server_location or "") if sub.server_location else "🌍",
            },
        }
    finally:
        session.close()
